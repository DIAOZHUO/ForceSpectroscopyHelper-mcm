class color:
    Log = '\033[92m'
    Warning = '\033[93m'
    Error = '\033[91m'
    End = '\033[0m'

